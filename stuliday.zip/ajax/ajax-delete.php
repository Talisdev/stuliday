<?php
 
    $annonce_ID = $_POST['annonce'];
    //Suppression annonce


    // Si ok, echo 'OK'
    echo $_POST['annonce'];
?>