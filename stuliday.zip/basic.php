<?php 
    require('inc/connect.php');
    require('inc/functions.php');
    require('inc/head.php');
    include('inc/nav.php'); 
?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            
            </div>
        </div>
    </div>
</section>
<?php 
    include('inc/footer.php'); 
?>