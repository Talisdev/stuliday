<?php
    $page = "index";
    require('inc/connect.php');
    require('inc/head.php');
    include('inc/header.php'); 
    include('inc/nav.php'); 
?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="annonces.php" class="btn btn-primary">Voir les annonces</a>

            </div>
        </div>
    </div>
</section>
<?php require('inc/footer.php'); ?>